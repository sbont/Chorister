package nl.stevenbontenbal.cymbali

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class CymbaliApplication

fun main(args: Array<String>) {
	runApplication<CymbaliApplication>(*args)
}
